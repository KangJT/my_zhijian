<template>
  <div class="swiper-container">
    <slot></slot>
    <!-- 如果需要分页器 -->
    <div class="swiper-pagination"></div>
</div>
</template>
<script>
import Swiper from 'swiper'
export default {
  name: 'Swiper',
  data () {
    return {

    }
  },
  props: {
    loop: {
      type: Boolean
    },
    autoplay: {
      type: Boolean
    },
    pagination: {
      type: Object,
      default: null
    }
  },
  mounted () {
    // eslint-disable-next-line no-new
    new Swiper('.swiper-container', {
      loop: this.loop,
      autoplay: this.autoplay,
      // 如果需要分页器
      pagination: this.pagination
    })
  }
}
</script>
<style scoped>
.swiper-pagination-fraction {
  width: 37px;
  height: 17px;
  background: rgba(0, 0, 0, .5);
  border-radius: 100px;
  color: #FFFFFF;
  font-size: 11px;
  line-height: 17px;
  right: 10px;
  left: auto;
}
</style>
<style>
.swiper-pagination-fraction span {
  display:inline-block;
  font-size: 11px;
}
</style>
