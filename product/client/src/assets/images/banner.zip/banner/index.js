import SwiperIn from './SwiperIn'
import Banner from './swipers'
export default {
  install (Vue) {
    Vue.component('SwiperIn', SwiperIn)
    Vue.component('Banner', Banner)
  }
}
